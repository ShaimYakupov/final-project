import React, { Component } from 'react'
import styles from '../header/header.scss'

import Registr from './Registr'

const Header  = () => {
    return (
          <header className='header'>
            <Registr/>
          </header>
        
    )
}

export default Header