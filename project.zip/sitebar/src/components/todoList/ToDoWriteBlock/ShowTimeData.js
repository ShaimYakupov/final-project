import React, { Component } from 'react'

// style
import styles from './todomainblock.module.scss'


const  ShowTimeData = () => {
    return (
      <>
        <div className={styles.showData__block}>
           
        </div>
      </>
    )
  
}
export default ShowTimeData