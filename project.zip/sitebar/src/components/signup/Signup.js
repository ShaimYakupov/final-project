import React, { Component } from 'react'

const Signup = ()=> {
    return(
        <>

        </>
    )
}

export default Signup