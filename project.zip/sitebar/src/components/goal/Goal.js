import React, { Component } from 'react'

const Goal = () => {
    return (
        <div>
          <h1> hello world</h1>
        </div>
      )
}
    
export default Goal
