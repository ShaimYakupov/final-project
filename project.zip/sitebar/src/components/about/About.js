import React, { Component } from 'react'
import { NavLink } from 'react-router-dom';


const info = [
  {
    name: 'info',
    link: '/About'
  }
]
const About = ()=> {
    return (
        <div className='info__block'>
          <div className='title'>8 708 937 2147</div>

        </div>
      )
}

export default About